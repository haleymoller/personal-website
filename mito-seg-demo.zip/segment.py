import numpy as np
from skimage import filters, morphology, segmentation, exposure
from scipy import ndimage as ndi

def segment_image(gray: np.ndarray) -> np.ndarray:
    # Simple classical pipeline:
    # 1) Contrast rescale
    # 2) Otsu threshold
    # 3) Morphological cleanup
    # 4) Distance transform + watershed to split clumps
    # Returns a binary mask (uint8 0/1).

    # 1) Contrast
    p2, p98 = np.percentile(gray, (2, 98))
    gray_eq = exposure.rescale_intensity(gray, in_range=(p2, p98))

    # 2) Threshold
    th = filters.threshold_otsu(gray_eq)
    init = gray_eq < th  # mitochondria often darker; flip if needed

    # 3) Morphology
    clean = morphology.remove_small_objects(init, 64)
    clean = morphology.remove_small_holes(clean, 64)
    clean = morphology.binary_opening(clean, morphology.disk(1))

    # 4) Watershed split
    distance = ndi.distance_transform_edt(clean)
    local_maxi = morphology.h_maxima(distance, 1.0)
    markers = ndi.label(local_maxi)[0]
    labels = segmentation.watershed(-distance, markers, mask=clean)

    # Final binary mask (any label >0 is foreground)
    mask = (labels > 0).astype(np.uint8)
    return mask
