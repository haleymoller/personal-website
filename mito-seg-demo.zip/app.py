import gradio as gr
import numpy as np
from PIL import Image
from segment import segment_image

TITLE = "EM Mitochondria Segmentation — Demo"
DESC = """
**Toy baseline** for segmenting mitochondria in electron micrographs.
This uses a lightweight classical pipeline (threshold + morphology + watershed).
Replace `segment.py` with your model (Cellpose/SAM/U-Net) to improve results.
"""

def run_seg(img: Image.Image):
    img = img.convert("L")
    arr = np.array(img)
    mask = segment_image(arr)  # returns 0/1 mask
    mask_rgb = np.stack([mask*255]*3, axis=-1).astype(np.uint8)
    vis = np.concatenate([np.stack([arr]*3, -1), mask_rgb], axis=1)
    return Image.fromarray(vis)

demo = gr.Interface(
    fn=run_seg,
    inputs=gr.Image(type="pil", label="Upload EM image"),
    outputs=gr.Image(type="pil", label="Original | Mask"),
    title=TITLE,
    description=DESC,
    examples=[["examples/em_sample.png"]],
)

if __name__ == "__main__":
    demo.launch()
