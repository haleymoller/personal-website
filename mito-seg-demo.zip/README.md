# Mitochondria Seg Demo (EM Images)

A tiny, open-source demo that segments mitochondria in electron micrographs using a lightweight classical pipeline (scikit-image) and a Gradio web app. It’s designed as a **starter** you can deploy publicly (Hugging Face Spaces) and later swap in stronger models (e.g., **Cellpose**, **SAM**, **U-Net**).

> ⚠️ This is a **toy baseline** (Otsu threshold + morphology + watershed). It is **not** state-of-the-art. Replace `segment.py` with your model-backed approach for real research use.

---

## Quickstart (local)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open the URL Gradio prints (e.g. http://127.0.0.1:7860).

---

## Deploy to Hugging Face Spaces

1. Create a new Space → **Gradio** template.  
2. In the Space, upload these files (or connect a Git repo): `app.py`, `segment.py`, `requirements.txt`, `LICENSE`, `README.md`, and `examples/`.  
3. Spaces will auto-build and host your app. Share the Space URL in your YC application.

**Tip:** If you prefer GitHub → Spaces, push this repo to GitHub, then in Spaces choose **"Connect with Git"**.

---

## Repo Layout

```
.
├── app.py
├── segment.py
├── requirements.txt
├── README.md
├── LICENSE
└── examples/
    └── em_sample.png
```

---

## Upgrading the Backend

Swap your model into `segment.py` but keep:

```python
def segment_image(gray: np.ndarray) -> np.ndarray:
    # returns a 0/1 uint8 mask
```

This way the Gradio UI in `app.py` keeps working unchanged.

---

## License

MIT — see `LICENSE`.
